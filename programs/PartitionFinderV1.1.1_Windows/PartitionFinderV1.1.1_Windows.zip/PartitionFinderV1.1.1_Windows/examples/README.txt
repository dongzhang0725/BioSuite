README for Examples
___________________


These folders contain two simple examples.

The /nucleotide folder demonstrates PartitionFinder
the /aminoacid folder demonstrates PartitionFinderProtein

Instructions on how to run these examples are provided in the manual:

For Mac Users: Page 7 of the manual
For Windows Users: Page 9 of the manual

Please email me if you have any questions.

Rob Lanfear
May 2012